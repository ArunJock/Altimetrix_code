from pyspark.sql import SparkSession
from pyspark.sql.types import StructType,StructField,StringType,IntegerType,FloatType
from pyspark.sql.functions import col,round,rank,when
from pyspark.sql.window import Window

spark = SparkSession.builder.appName("ETL_Pipeline").getOrCreate()

df_schema = StructType([StructField('Department',StringType(),True),
StructField('Dept_name',StringType(),True),
StructField('Division',StringType(),True),
StructField('Gender',StringType(),True),
StructField('Base_salary',StringType(),True),
StructField('Overtime_pay',FloatType(),True),
StructField('longevity_pay',FloatType(),True),
StructField('Grade',StringType(),True)])

df_data = spark.read.format("csv").schema(df_schema).option("header","true")\
.load("/home/ec2-user/environment/66139801620f9335369b230f/Project-Default/etl_code/Employee_Salaries.csv")

df_data.printSchema()

total_payout = df_data.withColumn("Total_pay",col("Base_salary")+col("Overtime_pay")+col("longevity_pay"))

total_payout_clean = total_payout.withColumn("Total_pay",round(total_payout["Total_pay"],2))

my_window = Window.partitionBy("Department").orderBy(total_payout_clean["Total_pay"].desc())

high_sal = total_payout_clean.withColumn("rnk",rank().over(my_window))

final_df = high_sal.filter("rnk <= 2")

final_df.printSchema()

#people_df = final_df.withColumn("Lead",when(final_df.rnk == 1 & final_df.Gender =='F'),"women").otherwise("men")
people_df = final_df.withColumn("Lead",when ((final_df.rnk == 1) & (final_df.Gender == 'F'),"Women").otherwise("Men"))

final_pep = people_df.filter("rnk ==1").select("Department","Total_pay","Grade","Lead")

final_pep.show()